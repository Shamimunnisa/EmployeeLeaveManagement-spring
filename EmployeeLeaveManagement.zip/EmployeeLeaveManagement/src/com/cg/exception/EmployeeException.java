package com.cg.exception;

@SuppressWarnings("serial")
public class EmployeeException extends Exception{
	public EmployeeException(String msg) {
		super(msg);
	}
}
