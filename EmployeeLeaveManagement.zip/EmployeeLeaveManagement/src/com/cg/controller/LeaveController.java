package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.Employee;
import com.cg.bean.Leave;
import com.cg.exception.EmployeeException;
import com.cg.service.ILeaveService;


@Controller
public class LeaveController {
	@Autowired
	ILeaveService eservice;
	

	@RequestMapping(value="/getleave" ,method=RequestMethod.POST)
	public String getEmployeeLeaves(int empid,Model m) throws EmployeeException {
		
		Employee em= eservice.getEmployeeById(empid);
		if(em!=null) {
			List<Leave> el= eservice.getEmpLeavesById(empid);
			if (!el.isEmpty()) {
				m.addAttribute("emps", em);
				m.addAttribute("leaves", el);
				return "ViewLeaveDetails";
			} else {
				m.addAttribute("emps", em);
				m.addAttribute("msg", "No Leave Record Found");
				return "ViewLeaveDetails";
			}
		}else {
			m.addAttribute("msg", "This Employee Id Does not exist...");
			return "Home";
		}
	}
}
